﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// LYCJ (c) 2009 - http://www.quickzip.org/components                                                            //
// Release under LGPL license.                                                                                   //
//                                                                                                               //
// This code used part of Steven Roebert's work (http://www.codeproject.com/KB/miscctrl/FileBrowser.aspx)        //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using ShellDll;
using System.Runtime.Serialization;
using System.Diagnostics;
using System.Collections.Generic;

namespace System.IO
{
    [Serializable]
    public class FileSystemInfoEx : FileSystemInfo, IDisposable, ISerializable, ICloneable,
        IEquatable<FileSystemInfoEx>
    {
        #region Enums

        [Flags]
        public enum RefreshModeEnum : int { None = 1 << 0, BaseProps = 1 << 1, FullProps =  1 << 2, AllProps = BaseProps | FullProps }

        #endregion

        #region Variables and Properties
        private string _name;
        internal DirectoryInfoEx _parent;
        private bool _parentInited = false;
        private PIDL _pidlRel = null;
        private PIDL _pidl = null;
        private FileAttributes _attributes;
        private DateTime _lastWriteTime, _lastAccessTime, _creationTime;
  
        public PIDL PIDLRel
        {
            get { return getRelPIDL(); ; }
        }
        public PIDL PIDL
        {
            get { return getPIDL(); }
        }

        public RefreshModeEnum RefreshMode { get; private set; }
        public override string Name { get { return _name; } }
        public new string Extension { get { return Path.GetExtension(Name); } }
        public override bool Exists { get { return getExists(); } }
        public DirectoryInfoEx Parent
        {
            get { initParent(); return _parent; }
            protected set
            {
                if (_parent != null)
                    throw new Exception("_parent cannot be reset."); _parent = value;
            }
        }
        public string Label { get; protected set; }
        public new string FullName { get; protected set; }
        public new FileAttributes Attributes { get { checkRefresh(); return _attributes; } set { _attributes = value; } }
        public new DateTime LastWriteTime { get { checkRefresh(); return _lastWriteTime; } set { _lastWriteTime = value; } }
        public new DateTime LastWriteTimeUtc { get { return LastWriteTime.ToUniversalTime(); } }
        public new DateTime LastAccessTime { get { checkRefresh(); return _lastAccessTime; } set { _lastAccessTime = value; } }
        public new DateTime LastAccessTimeUtc { get { return LastAccessTime.ToUniversalTime(); } }
        public new DateTime CreationTime { get { checkRefresh(); return _creationTime; } set { _creationTime = value; } }
        public new DateTime CreationTimeUtc { get { return CreationTime.ToUniversalTime(); } }
        public bool IsFolder { get { return (Attributes & FileAttributes.Directory) == FileAttributes.Directory; } }

        protected void initParent()
        {
            if (!_parentInited)
                if (Exists)
                {
                    if (FullName.Equals(IOTools.IID_Desktop)) return;
                    PIDL relPIDL;
                    _parent = new DirectoryInfoEx(getParentPIDL(PIDL, out relPIDL));
                    _parentInited = true;

                    relPIDL.Free();
                }
                else
                {
                    _parent = new DirectoryInfoEx(PathEx.GetDirectoryName(FullName));
                    _parentInited = true;
                }
        }

        //0.12: Fixed PIDL, PIDLRel, ShellFolder, Storage properties generated on demand to avoid x-thread issues.
        private PIDL getRelPIDL()
        {
            if (_pidlRel != null) //0.14 : FileSystemInfoEx now stored a copy of PIDL/Rel, will return copy of it when properties is called (to avoid AccessViolation). 
                return new PIDL(_pidlRel, true);


            //0.16: Fixed getRelPIDL() cannot return correct value if File/DirInfoEx construct with string. (attemp to return a freed up pointer).
            //PIDL pidlLookup = PIDL;
            //try
            //{
            return getRelativePIDL(PIDL);
            //}
            //finally
            //{
            //    if (pidlLookup != null)
            //        pidlLookup.Free();
            //    pidlLookup = null;
            //}
        }

        private PIDL getPIDL()
        {
            if (_pidl != null)
                return new PIDL(_pidl, true);

            if (FullName == "::{00021400-0000-0000-C000-000000000046}") //Desktop
                return DirectoryInfoEx.CSIDLtoPIDL(ShellAPI.CSIDL.DESKTOP);
            else
                return PathToPIDL(FullName);
        }

        private bool getExists()
        {
            if (FullName == "::{00021400-0000-0000-C000-000000000046}") //Desktop
                return true;
            else if (FullName == null) return false;
            else
                try
                {
                    if (_pidl != null)
                    {
                        using (ShellFolder2 _desktopShellFolder = getDesktopShellFolder())
                            loadName(_desktopShellFolder, _pidl, ShellAPI.SHGNO.FORPARSING);
                        return true;
                    }
                    else
                    {
                        PIDL pidlLookup = PathToPIDL(FullName);
                        try
                        {
                            return pidlLookup != null;
                        }
                        finally { if (pidlLookup != null) pidlLookup.Free(); }
                    }
                }
                catch (FileNotFoundException)
                {
                    return false;
                }
        }

        #endregion


        #region Static Methods
        public static FileSystemInfoEx FromString(string FullName)
        {
            return DirectoryEx.Exists(FullName) ? (FileSystemInfoEx)new DirectoryInfoEx(FullName) : new FileInfoEx(FullName);
        }

        internal static ShellFolder2 getDesktopShellFolder()
        {
            IntPtr ptrShellFolder;
            int hr = ShellAPI.SHGetDesktopFolder(out ptrShellFolder);
            if (hr == ShellAPI.S_OK && ptrShellFolder != IntPtr.Zero)
            {
                ShellFolder2 sf = new ShellFolder2(ptrShellFolder);
                //0.13: Fixed? Desktop ShellFolder not released. (may be a cause of AccessViolationException.)
                //GC.SuppressFinalize(sf);
                return sf;
            }
            else Marshal.ThrowExceptionForHR(hr);

            return null; //mute error.
        }

        internal static PIDL PathToPIDL(string path)
        {
            path = Helper.RemoveSlash(path);
            IntPtr pidlPtr;
            uint pchEaten = 0;
            ShellAPI.SFGAO pdwAttributes = 0;

            using (ShellFolder2 _desktopShellFolder = getDesktopShellFolder())
            {
                int hr = _desktopShellFolder.ParseDisplayName(
                    IntPtr.Zero, IntPtr.Zero, path, ref pchEaten, out pidlPtr, ref pdwAttributes);

                if (pidlPtr == IntPtr.Zero || hr != ShellAPI.S_OK)
                { /*Marshal.ThrowExceptionForHR(hr);*/ return null; }
                //Commented because this is part of init and it's too time consuming.
            }
            return new PIDL(pidlPtr, false);
        }


        internal static string PIDLToPath(PIDL pidlFull)
        {
            PIDL desktopPIDL = DirectoryInfoEx.DesktopDirectory.PIDL;
            if (pidlFull.Equals(desktopPIDL))
                return "::{00021400-0000-0000-C000-000000000046}";
            if (desktopPIDL != null) desktopPIDL.Free(); desktopPIDL = null;

            using (ShellFolder2 _desktopShellFolder = getDesktopShellFolder())
                return loadName(_desktopShellFolder, pidlFull, ShellAPI.SHGNO.FORPARSING);
        }

        internal static string PIDLToPath(IShellFolder2 iShellFolder, PIDL pidlRel)
        {
            return loadName(iShellFolder, pidlRel, ShellAPI.SHGNO.FORPARSING);
        }

        internal static PIDL getRelativePIDL(PIDL pidl)
        {
            if (pidl == null)
                return null;
            IntPtr pRelPIDL = PIDL.ILFindLastID(pidl.Ptr);
            if (pRelPIDL == IntPtr.Zero)
                throw new IOException("getRelativePIDL");
            return new PIDL(pRelPIDL, true); //0.21
        }

        internal static PIDL getParentPIDL(PIDL pidl, out PIDL relPIDL)
        {
            relPIDL = new PIDL(pidl, true); //0.21
            if (pidl.Size == 0)
                return pidl;
            IntPtr pParent = PIDL.ILClone(pidl.Ptr);

            relPIDL = getRelativePIDL(pidl);
            if (pParent == IntPtr.Zero || !PIDL.ILRemoveLastID2(ref pParent))
                return DirectoryInfoEx.CSIDLtoPIDL(ShellAPI.CSIDL.DESKTOP);

            return new PIDL(pParent, false); //pParent will be freed by the PIDL.
        }

        //internal static string getParentParseName(PIDL pidl)
        //{
        //    PIDL relPIDL;
        //    PIDL parentPIDL = getParentPIDL(pidl, out relPIDL);
        //    IShellFolder sf = getParentIShellFolder(parentPIDL, out relPIDL);
        //    if (relPIDL.Size == 0)
        //        return IOTools.IID_Desktop;
        //    return loadName(sf, relPIDL, ShellAPI.SHGNO.FORPARSING);
        //}

        internal static ShellFolder2 getParentIShellFolder(PIDL pidl, out PIDL relPIDL)
        {
            int hr;
            IntPtr ptrShellFolder = IntPtr.Zero;

            if (pidl.Size == 0 || PIDL.ILFindLastID(pidl.Ptr) == pidl.Ptr || //is root or parent is root
                PIDLToPath(pidl) == Environment.GetFolderPath(Environment.SpecialFolder.Desktop))
            {

                hr = ShellAPI.SHGetDesktopFolder(out ptrShellFolder);
                relPIDL = new PIDL(pidl, true);
            }
            else
            {
                PIDL parentPIDL = getParentPIDL(pidl, out relPIDL);

                //Console.WriteLine("ParentPIDL.Size = {0}", parentPIDL.Size);
                System.Guid guid = ShellAPI.IID_IShellFolder2;
                using (ShellFolder2 _desktopShellFolder = getDesktopShellFolder())
                    hr = _desktopShellFolder.BindToObject(parentPIDL.Ptr, IntPtr.Zero,
                        ref guid, out ptrShellFolder);

                if (parentPIDL != null) parentPIDL.Free();
            }

            if (hr == ShellAPI.S_OK && ptrShellFolder != IntPtr.Zero)
                return new ShellFolder2(ptrShellFolder);
            else Marshal.ThrowExceptionForHR(hr);

            return null; //mute error.
        }

        protected static ShellDll.ShellAPI.SFGAO shGetFileAttribute(PIDL pidl, ShellDll.ShellAPI.SFGAO lookup)
        {
            ShellAPI.SHFILEINFO shfi = new ShellAPI.SHFILEINFO();
            shfi.dwAttributes = ShellAPI.SFGAO.READONLY | ShellAPI.SFGAO.HIDDEN | ShellAPI.SFGAO.BROWSABLE |
                ShellAPI.SFGAO.FILESYSTEM | ShellAPI.SFGAO.HASSUBFOLDER;
            ShellAPI.SHGFI dwFlag = ShellAPI.SHGFI.PIDL | ShellAPI.SHGFI.ATTRIBUTES | ShellAPI.SHGFI.ATTR_SPECIFIED | ShellAPI.SHGFI.USEFILEATTRIBUTES;
            ShellAPI.FILE_ATTRIBUTE dwAttr = 0;
            int cbFileInfo = Marshal.SizeOf(shfi.GetType());
            IntPtr retPtr = ShellAPI.SHGetFileInfo(pidl.Ptr, dwAttr, ref shfi, cbFileInfo, dwFlag);

            if (retPtr.ToInt32() != ShellAPI.S_OK && retPtr.ToInt32() != 1)
                Marshal.ThrowExceptionForHR(retPtr.ToInt32());
            return shfi.dwAttributes;
        }


        private static FileAttributes loadAttributes(IShellFolder2 iShellFolder, PIDL pidlFull, PIDL pidlRel)
        {
            FileAttributes retVal = new FileAttributes();


            //ShellAPI.SFGAO attribute = shGetFileAttribute(pidlFull, ShellAPI.SFGAO.READONLY |
            //    ShellAPI.SFGAO.FOLDER | ShellAPI.SFGAO.FILESYSTEM | ShellAPI.SFGAO.STREAM | ShellAPI.SFGAO.FILESYSANCESTOR |
            //    ShellAPI.SFGAO.HIDDEN);
            ShellAPI.SFGAO attribute = ShellAPI.SFGAO.READONLY | ShellAPI.SFGAO.FOLDER | ShellAPI.SFGAO.FILESYSTEM | ShellAPI.SFGAO.STREAM | ShellAPI.SFGAO.FILESYSANCESTOR;
            iShellFolder.GetAttributesOf(1, new IntPtr[] { pidlRel.Ptr }, ref attribute);

            if (!IOTools.IsZip(attribute) && (attribute & ShellAPI.SFGAO.FOLDER) != 0) retVal |= FileAttributes.Directory;
            if ((attribute & ShellAPI.SFGAO.HIDDEN) != 0) retVal |= FileAttributes.Hidden;
            if ((attribute & ShellAPI.SFGAO.READONLY) != 0) retVal |= FileAttributes.ReadOnly;

            return retVal;
        }

        private static string loadName(IShellFolder2 iShellFolder, ShellAPI.SHGNO uFlags)
        {
            return loadName(iShellFolder, new PIDL(IntPtr.Zero, false), uFlags);
        }

        private static string loadName(IShellFolder2 iShellFolder, PIDL relPidl, ShellAPI.SHGNO uFlags)
        {
            if (iShellFolder == null) return null;

            IntPtr ptrStr = Marshal.AllocCoTaskMem(ShellAPI.MAX_PATH * 2 + 4);
            Marshal.WriteInt32(ptrStr, 0, 0);
            StringBuilder buf = new StringBuilder(ShellAPI.MAX_PATH);

            try
            {
                if (iShellFolder.GetDisplayNameOf(relPidl.Ptr, uFlags, ptrStr) == ShellAPI.S_OK)
                    ShellAPI.StrRetToBuf(ptrStr, relPidl.Ptr, buf, ShellAPI.MAX_PATH);
            }
            finally
            {
                if (ptrStr != IntPtr.Zero)
                    Marshal.FreeCoTaskMem(ptrStr);
                ptrStr = IntPtr.Zero;
            }
            return buf.ToString();
        }


        #endregion

        #region Methods


        protected virtual void refresh(IShellFolder2 parentShellFolder, PIDL relPIDL, PIDL fullPIDL, RefreshModeEnum mode)
        {
            if (parentShellFolder != null && fullPIDL != null && relPIDL != null)
            {

                Attributes = loadAttributes(parentShellFolder, fullPIDL, relPIDL);
                string parseName = loadName(parentShellFolder, relPIDL, ShellAPI.SHGNO.FORPARSING);
                FullName = "";

                //Console.WriteLine("relPIDL.size = {0}", relPIDL.Size);
                //Console.WriteLine("PIDL.size = {0}", _pidl.Size); 


                if (relPIDL.Size == 0)
                    FullName = IOTools.IID_Desktop;
                else
                //0.12: Fixed Fullname of User/Shared directory under desktop is now it's GUID instead of it's file path.
                //0.13: Fixed All subdirectory under User/Shared directory uses GUID now.
                {
                    if (DirectoryInfoEx.CurrentUserDirectory != null)
                    {
                        if (parseName == DirectoryInfoEx.CurrentUserDirectory.FullName &&
                        loadName(parentShellFolder, ShellAPI.SHGNO.FORPARSING) == Environment.GetFolderPath(Environment.SpecialFolder.Desktop))
                        {
                            FullName = IOTools.IID_UserFiles;
                        }
                        //else if (
                        //    (parseName.StartsWith(DirectoryInfoEx.CurrentUserDirectory.FullName) &&
                        //    _parent != null && _parent.FullName.StartsWith(IOTools.IID_UserFiles))
                        //    ||
                        //    (OriginalPath != null && OriginalPath.StartsWith(IOTools.IID_UserFiles))
                        //    )
                        //{                            
                        //    FullName = parseName.Replace(DirectoryInfoEx.CurrentUserDirectory.FullName, IOTools.IID_UserFiles);
                        //}
                    }

                    if (DirectoryInfoEx.SharedDirectory != null)
                    {
                        if (parseName == DirectoryInfoEx.SharedDirectory.FullName &&
                        loadName(parentShellFolder, ShellAPI.SHGNO.FORPARSING) == Environment.GetFolderPath(Environment.SpecialFolder.Desktop))
                            FullName = IOTools.IID_Public;
                        //else if (
                        //    (parseName.StartsWith(DirectoryInfoEx.SharedDirectory.FullName) &&
                        //    _parent != null && _parent.FullName.StartsWith(IOTools.IID_Public))
                        //    ||
                        //    (OriginalPath != null && OriginalPath.StartsWith(IOTools.IID_Public))
                        //    )
                        //    FullName = parseName.Replace(DirectoryInfoEx.SharedDirectory.FullName, IOTools.IID_Public);
                    }

                    //if (_parent != null && _parent.FullName.StartsWith(IOTools.IID_Library)
                    //    && !parseName.StartsWith(IOTools.IID_Library))
                    //    FullName = PathEx.Combine(_parent.FullName, PathEx.GetFileName(parseName));

                    if (FullName == "")
                        FullName = parseName;
                }
                //if (DirectoryInfoEx.CurrentUserDirectory != null && parseName == DirectoryInfoEx.CurrentUserDirectory.FullName &&
                //loadName(parentShellFolder, ShellAPI.SHGNO.FORPARSING) == Environment.GetFolderPath(Environment.SpecialFolder.Desktop))
                //    FullName = IOTools.IID_UserFiles;
                //else

                //if (DirectoryInfoEx.SharedDirectory != null && parseName == DirectoryInfoEx.SharedDirectory.FullName &&
                //    loadName(parentShellFolder, ShellAPI.SHGNO.FORPARSING) == Environment.GetFolderPath(Environment.SpecialFolder.Desktop))
                //    FullName = IOTools.IID_Public;
                //else


                if (OriginalPath == null)
                    OriginalPath = FullName;
                if (parseName.StartsWith("::")) //Guid
                    parseName = loadName(parentShellFolder, relPIDL, ShellAPI.SHGNO.NORMAL);

                _name = FullName.EndsWith("\\") ? FullName : PathEx.GetFileName(FullName);
                Label = loadName(parentShellFolder, relPIDL, ShellAPI.SHGNO.NORMAL);


            }
            else
            {
                if (OriginalPath != null)
                {
                    string origPath = Helper.RemoveSlash(OriginalPath);
                    _name = Path.GetFileName(origPath);
                    Label = _name;
                    FullName = origPath;
                }
            }
        }

        protected void checkRefresh(RefreshModeEnum mode = RefreshModeEnum.AllProps)
        {
            if ((RefreshMode & mode) != mode)
                Refresh(mode);
        }

        /// <summary>
        /// Refresh the file / directory info. Does not refresh directory contents 
        /// because it refresh every time GetFiles/Directories/FileSystemInfos is called.
        /// </summary>
        public new void Refresh(RefreshModeEnum mode = RefreshModeEnum.AllProps )
        {
            RefreshMode |= mode; //0.23 : Delay loading some properties.

            PIDL relPIDL = null;
            if (!Exists)
                refresh(null, null, null, mode);
            else
                try
                {
                    //0.16: Fixed ShellFolder not freed
                    using (ShellFolder2 sf = getParentIShellFolder(PIDL, out relPIDL))
                        refresh(sf, relPIDL, PIDL, mode);
                }
                catch (NullReferenceException)
                {
                    refresh(null, null, null, mode);
                }
                finally
                {
                    if (relPIDL != null)
                        relPIDL.Free();
                    relPIDL = null;
                }

        }

        /// <summary>
        /// Delete the current item.
        /// </summary>
        public override void Delete()
        {
            if (this is FileInfoEx)
                (this as FileInfoEx).Delete();
            else
                (this as DirectoryInfoEx).Delete();
        }

        /// <summary>
        /// Return if two FileSystemInfoEx is equal (using PIDL if possible, otherwise Path)
        /// </summary>
        public virtual bool Equals(FileSystemInfoEx other)
        {
            if (PIDL != null)
                return PIDL.Equals(other.PIDL);
            else return FullName.Equals(other.FullName, StringComparison.InvariantCultureIgnoreCase);

        }

        public override bool Equals(object obj)
        {
            if (obj is FileSystemInfoEx)
                return Equals((FileSystemInfoEx)obj);
            return false;
        }

        public override int GetHashCode()
        {
            return IOTools.GetHashCode(this);
        }

        public override string ToString()
        {
            return Label;
        }

        #endregion

        #region Constructors
        protected virtual void checkProperties()
        {
        }

        protected void init(PIDL fullPIDL)
        {
            PIDL relPIDL = null;
            //0.16: Fixed ShellFolder not freed
            using (ShellFolder2 parentShellFolder = getParentIShellFolder(fullPIDL, out relPIDL))
                refresh(parentShellFolder, relPIDL, fullPIDL, RefreshModeEnum.BaseProps);
            _pidl = new PIDL(fullPIDL, true); //0.14 : FileSystemInfoEx record the pidl when construct, as some path do not parasable (e.g. EntireNetwork)
            _pidlRel = relPIDL;
        }

        protected void init(IShellFolder2 parentShellFolder, PIDL fullPIDL)
        {
            PIDL relPIDL = null;
            getParentPIDL(fullPIDL, out relPIDL);
            refresh(parentShellFolder, relPIDL, fullPIDL, RefreshModeEnum.BaseProps);
            _pidl = new PIDL(fullPIDL, true);
            _pidlRel = relPIDL;
        }

        protected void init(IShellFolder2 parentShellFolder, PIDL parentPIDl, PIDL relPIDL)
        {
            PIDL fullPIDL = new PIDL(PIDL.ILCombine(parentPIDl.Ptr, relPIDL.Ptr), false);

            refresh(parentShellFolder, relPIDL, fullPIDL, RefreshModeEnum.BaseProps);
            _pidl = fullPIDL;
            _pidlRel = new PIDL(relPIDL, true);
        }


        protected void init(string path)
        {
            //0.22: Fix illegal PIDL for Directory under Library.ms directory
            _pidl = null;
            _pidlRel = null;
            OriginalPath = path;
            FullName = path;
            Refresh(RefreshModeEnum.BaseProps);
        }

        protected void init(SerializationInfo info, StreamingContext context)
        {
            OriginalPath = info.GetString("OriginalPath");
            Label = info.GetString("Label");
            _name = info.GetString("Name");
            FullName = info.GetString("FullName");
            Attributes = (FileAttributes)info.GetValue("Attributes", typeof(FileAttributes));
            LastWriteTime = info.GetDateTime("LastWriteTime");
            LastAccessTime = info.GetDateTime("LastAccessTime");
            CreationTime = info.GetDateTime("CreationTime");
        }

        internal FileSystemInfoEx(string fullPath)
        {
            init(fullPath);
        }

        protected FileSystemInfoEx(SerializationInfo info, StreamingContext context)
            : base()
        {
            init(info, context);
        }

        protected FileSystemInfoEx()
        {

        }

        #endregion


        #region ISerializable Members
        protected virtual void getObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("OriginalPath", OriginalPath);
            info.AddValue("Label", Label);
            info.AddValue("Name", Name);
            info.AddValue("FullName", FullName);
            info.AddValue("Attributes", Attributes);
            info.AddValue("LastWriteTime", LastWriteTime);
            info.AddValue("LastAccessTime", LastAccessTime);
            info.AddValue("CreationTime", CreationTime);

        }

        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            getObjectData(info, context);
        }

        #endregion

        #region IDisposable Members

        ~FileSystemInfoEx()
        {
            ((IDisposable)this).Dispose();
        }

        public void Dispose()
        {
            if (_pidlRel != null) _pidlRel.Free();
            if (_pidl != null) _pidl.Free();
            _pidlRel = null;
            _pidl = null;
        }

        #endregion

        #region ICloneable Members

        public object Clone()
        {
            return new FileSystemInfoEx(this.FullName);
        }

        #endregion
    }
}
